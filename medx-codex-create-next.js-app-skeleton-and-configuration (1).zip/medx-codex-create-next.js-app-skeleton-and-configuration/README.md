# MedX — One-shot Launch Starter

This project includes:
- **Banner aggregator** (WHO, ClinicalTrials, openFDA, PubMed)
- **Chat** that proxies to a **self-hosted LLM** (OpenAI-compatible endpoint like vLLM/Ollama)
- Dark/Light theme, PWA manifest
- Minimal UI with Patient/Clinician toggle
- API wrappers for PubMed, openFDA, ClinicalTrials, DailyMed, RxNorm, ICD-11

## Run
1. Copy `.env.example` → `.env.local` and fill:
   - `NCBI_API_KEY` `OPENFDA_API_KEY`
   - `ICD11_CLIENT_ID` `ICD11_CLIENT_SECRET`
   - `LLM_BASE_URL` (e.g., `https://llm.your-vpc/v1` for vLLM/Ollama OpenAI-compatible API)
   - `LLM_MODEL_ID` (e.g., `llama3-8b-instruct`)
2. `npm install`
3. `npm run dev`

## Deploy
- Push to GitHub → Import into Vercel → add same env vars → Deploy.

## Endpoints
- `GET /api/banner` — aggregated headlines
- `POST /api/chat` — body: `{question, role: "patient"|"clinician"}`
- Plus wrappers: `/api/clinicaltrials`, `/api/pubmed`, `/api/who`, `/api/openfda`, `/api/dailymed`, `/api/rxnorm`, `/api/icd11`

## Notes
- No OpenAI/Gemini dependency. Use your own LLM endpoint.
- Images for banner should follow source licenses; this demo just returns text/meta.
